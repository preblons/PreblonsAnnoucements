/*
Plugin de Annoucements.
Criado por Preblons!
 */

package com.preblons.commands;

import com.preblons.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class UrgenteCommand implements CommandExecutor {

    private Main plugin;

    public UrgenteCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("preblons.urgente")) {
            sender.sendMessage("§cVocê não tem permissão de executar esse comando.");
            return false;
        }

        if (args.length == 0) {
            sender.sendMessage("§cPor favor, forneça uma mensagem.");
            return false;
        }

        FileConfiguration config = plugin.getConfig();
        String titulo = config.getString("urgente.titulo").replace("&", "§");
        String subtitulo = config.getString("urgente.subtitulo").replace("&", "§");
        String prefixo = config.getString("urgente.prefixo").replace("&", "§");

        String mensagem = String.join(" ", args);

        String mensagemFormatada = prefixo.replace("{message}", mensagem);
        Bukkit.broadcastMessage("\n" + mensagemFormatada + "\n");

        for (Player player : Bukkit.getOnlinePlayers()) {
            sendTitle(player, titulo, subtitulo);
            clearTitle(player, 60);
        }

        return true;
    }

    private void sendTitle(Player player, String titulo, String subtitulo) {
        player.sendTitle(titulo, subtitulo);
    }

    private void clearTitle(Player player, int delay) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> player.sendTitle("", ""), delay);
    }
}
