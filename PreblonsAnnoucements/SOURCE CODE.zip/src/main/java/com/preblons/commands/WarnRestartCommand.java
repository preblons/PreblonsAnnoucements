/*
Plugin de Annoucements.
Criado por Preblons!
 */

package com.preblons.commands;

import com.preblons.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.lang.reflect.Method;

public class WarnRestartCommand implements CommandExecutor {

    private Main plugin;
    private BukkitRunnable restartTask;

    public WarnRestartCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("preblons.warnrestart")) {
            sender.sendMessage("§cVocê não tem permissão para executar este comando.");
            return false;
        }

        if (args.length == 0) {
            sender.sendMessage("§cPor favor, forneça o tempo no formato correto. Exemplo: /warnrestart 10s");
            return false;
        }

        if (args[0].equalsIgnoreCase("cancel")) {
            cancelRestart(sender);
            return true;
        }

        String timeArg = args[0];
        long timeInMillis = convertToMillis(timeArg);
        if (timeInMillis == -1) {
            sender.sendMessage("§cFormato de tempo inválido. Use 1s, 1m ou 1h.");
            return false;
        }

        startRestartCountdown(timeInMillis, sender);
        return true;
    }

    private long convertToMillis(String time) {
        try {
            if (time.endsWith("s")) {
                return Integer.parseInt(time.replace("s", "")) * 1000;
            } else if (time.endsWith("m")) {
                return Integer.parseInt(time.replace("m", "")) * 60000;
            } else if (time.endsWith("h")) {
                return Integer.parseInt(time.replace("h", "")) * 3600000;
            }
        } catch (NumberFormatException e) {
            return -1;
        }
        return -1;
    }

    private void startRestartCountdown(long timeInMillis, CommandSender sender) {
        if (restartTask != null) {
            sender.sendMessage("§cJá há um reinício em andamento.");
            return;
        }

        final int initialTime = (int) (timeInMillis / 1000);

        restartTask = new BukkitRunnable() {
            int timeLeft = initialTime;

            @Override
            public void run() {
                if (timeLeft <= 0) {
                    Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "restart");
                    cancel();
                    return;
                }

                String actionBarMessage = "§4§lReiniciando em: " + timeLeft + "s";
                for (Player player : Bukkit.getOnlinePlayers()) {
                    sendActionBar(player, actionBarMessage);
                }

                timeLeft--;
            }
        };

        restartTask.runTaskTimer(plugin, 0, 20);
    }

    private void cancelRestart(CommandSender sender) {
        if (restartTask == null) {
            sender.sendMessage("§cNão há reinício programado.");
            return;
        }

        restartTask.cancel();
        restartTask = null;

        for (Player player : Bukkit.getOnlinePlayers()) {
            sendActionBar(player, ""); // Limpa a ActionBar
        }

        sender.sendMessage("§aReinício cancelado com sucesso.");
    }

    private void sendActionBar(Player player, String message) {
        try {
            if (message == null || message.isEmpty()) {
                message = "";
            }

            Object chatComponent = getNMSClass("IChatBaseComponent")
                    .getDeclaredClasses()[0]
                    .getMethod("a", String.class)
                    .invoke(null, "{\"text\":\"" + message + "\"}");

            Object packet = getNMSClass("PacketPlayOutChat")
                    .getConstructor(getNMSClass("IChatBaseComponent"), byte.class)
                    .newInstance(chatComponent, (byte) 2);

            Object handle = player.getClass().getMethod("getHandle").invoke(player);
            Object playerConnection = handle.getClass().getField("playerConnection").get(handle);
            Method sendPacket = playerConnection.getClass().getMethod("sendPacket", getNMSClass("Packet"));

            sendPacket.invoke(playerConnection, packet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Class<?> getNMSClass(String name) throws ClassNotFoundException {
        return Class.forName("net.minecraft.server." + Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3] + "." + name);
    }
}
