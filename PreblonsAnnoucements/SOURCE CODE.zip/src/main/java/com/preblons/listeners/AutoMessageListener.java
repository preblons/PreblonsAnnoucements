/*
Plugin de Annoucements.
Criado por Preblons!
 */

package com.preblons.listeners;

import com.preblons.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;

public class AutoMessageListener {

    private Main plugin;
    private BukkitTask autoMessageTask;
    private boolean isTaskRunning;

    public AutoMessageListener(Main plugin) {
        this.plugin = plugin;
        this.isTaskRunning = false;
    }

    public void start() {
        FileConfiguration config = plugin.getConfig();

        List<String> messagesList = config.getStringList("autoMessages.messages");
        int delay = config.getInt("autoMessages.delay", 60);

        if (!messagesList.isEmpty()) {
            if (isTaskRunning) {
                autoMessageTask.cancel();
            }

            autoMessageTask = new BukkitRunnable() {
                int messageIndex = 0;

                @Override
                public void run() {
                    if (messageIndex < messagesList.size()) {
                        String message = ChatColor.translateAlternateColorCodes('&', messagesList.get(messageIndex));
                        Bukkit.broadcastMessage(message);
                        messageIndex++;
                    } else {
                        messageIndex = 0;
                    }
                }
            }.runTaskTimer(plugin, 0, delay);

            isTaskRunning = true;
        }
    }

    public void cancelAutoMessages() {
        if (autoMessageTask != null && isTaskRunning) {
            autoMessageTask.cancel();
            isTaskRunning = false;
        }
    }
}
